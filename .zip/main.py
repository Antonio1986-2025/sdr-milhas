"""
main.py
-------
Servidor principal do SDR Milhas.
Recebe webhooks da Evolution API (mensagens do WhatsApp)
e coordena todo o fluxo de qualificação.

Para rodar localmente:
  uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, Request, HTTPException
from contextlib import asynccontextmanager

from config import PORT
from database import (
    upsert_lead,
    buscar_lead_por_whatsapp,
    atualizar_lead,
    salvar_mensagem,
    buscar_historico,
    criar_agendamento,
)
from agent import chamar_gpt
from whatsapp import enviar_mensagem
from repasse import executar_repasse
from followup import iniciar_loop_followup


# ─────────────────────────────────────────────
# INICIALIZAÇÃO
# ─────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Código que roda quando o servidor inicia.
    Aqui iniciamos o loop de follow-up em background.
    """
    print("🚀 SDR Milhas iniciado!")
    iniciar_loop_followup()
    yield
    print("👋 SDR Milhas encerrado.")


app = FastAPI(
    title="SDR Milhas",
    description="Agente de vendas automático para gestão de milhas aéreas",
    lifespan=lifespan,
)


# ─────────────────────────────────────────────
# ROTA DE SAÚDE (health check)
# ─────────────────────────────────────────────

@app.get("/")
def health_check():
    """Rota simples para verificar se o servidor está rodando."""
    return {"status": "ok", "servico": "SDR Milhas"}


# ─────────────────────────────────────────────
# WEBHOOK PRINCIPAL (Workflow 1)
# ─────────────────────────────────────────────

@app.post("/sdr-milhas")
async def receber_webhook(request: Request):
    """
    Recebe mensagens do WhatsApp via Evolution API.
    
    Fluxo completo:
    1. Extrai dados da mensagem
    2. Ignora mensagens enviadas por nós mesmos
    3. Cria ou busca o lead no banco
    4. Salva a mensagem recebida
    5. Busca histórico da conversa
    6. Chama a Lara (GPT) para gerar resposta
    7. Atualiza o lead com novos dados
    8. Se agendou: cria agendamento + envia ficha pro Pedro
    9. Envia a resposta ao lead
    """
    try:
        dados = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="JSON inválido")

    # ── 1. Extrai os dados do webhook da Evolution API ──
    # A Evolution manda os dados dentro de "data"
    data = dados.get("data", {})
    
    # Ignora mensagens enviadas por nós (evita loop infinito)
    if data.get("key", {}).get("fromMe") is True:
        return {"status": "ignorado", "motivo": "mensagem própria"}

    # Extrai o número do WhatsApp (remove sufixo @s.whatsapp.net se existir)
    whatsapp_raw = data.get("key", {}).get("remoteJid", "")
    whatsapp = whatsapp_raw.replace("@s.whatsapp.net", "").replace("@c.us", "")

    if not whatsapp:
        return {"status": "ignorado", "motivo": "sem número"}

    # Nome do contato (pode não vir sempre)
    nome = data.get("pushName") or data.get("key", {}).get("remoteJid", "").split("@")[0]

    # Texto da mensagem
    mensagem_recebida = (
        data.get("message", {}).get("conversation")
        or data.get("message", {}).get("extendedTextMessage", {}).get("text")
        or ""
    )

    if not mensagem_recebida:
        return {"status": "ignorado", "motivo": "mensagem sem texto"}

    # ID da mensagem na Evolution (para evitar duplicatas)
    evolution_msg_id = data.get("key", {}).get("id", "")

    print(f"[WEBHOOK] {whatsapp} ({nome}): {mensagem_recebida[:50]}")

    # ── 2. Cria ou busca o lead ──
    lead = upsert_lead(whatsapp, nome)

    # ── 3. Salva a mensagem recebida ──
    salvar_mensagem(
        lead_id=lead["id"],
        direcao="RECEBIDA",
        conteudo=mensagem_recebida,
        etapa=lead.get("etapa", "ABERTURA"),
        evolution_msg_id=evolution_msg_id,
    )

    # ── 4. Busca histórico para dar contexto ao GPT ──
    historico = buscar_historico(lead["id"], limite=10)

    # ── 5. Chama a Lara (GPT-4o-mini) ──
    resposta = chamar_gpt(lead, mensagem_recebida, historico)

    mensagem_lara = resposta.get("mensagem", "Oi! Pode repetir? 😊")
    proxima_etapa = resposta.get("proxima_etapa", lead.get("etapa", "ABERTURA"))
    temperatura = resposta.get("temperatura", lead.get("temperatura", "INDEFINIDO"))
    acao = resposta.get("acao", "NENHUMA")
    dados_capturados = resposta.get("dados_capturados", {})

    # ── 6. Atualiza o lead no banco ──
    campos_atualizar = {
        "etapa": proxima_etapa,
        "temperatura": temperatura,
        "ultima_interacao": "now()",
    }

    # Status baseado na etapa
    if proxima_etapa == "CONFIRMADO":
        campos_atualizar["status"] = "AGENDADO"
    elif proxima_etapa == "DESCARTADO":
        campos_atualizar["status"] = "DESCARTADO"
    elif lead.get("status") == "NOVO":
        campos_atualizar["status"] = "EM_QUALIFICACAO"

    # Dados capturados pelo GPT
    if dados_capturados.get("gasto_mensal"):
        campos_atualizar["gasto_mensal"] = dados_capturados["gasto_mensal"]
    if dados_capturados.get("gasto_faixa"):
        campos_atualizar["gasto_faixa"] = dados_capturados["gasto_faixa"]
    if dados_capturados.get("cartoes_atuais"):
        campos_atualizar["cartoes_atuais"] = dados_capturados["cartoes_atuais"]
    if dados_capturados.get("destino_viagem"):
        campos_atualizar["destino_viagem"] = dados_capturados["destino_viagem"]
    if dados_capturados.get("milhas_atuais"):
        campos_atualizar["milhas_atuais"] = dados_capturados["milhas_atuais"]
    if dados_capturados.get("tem_milhas") is not None:
        campos_atualizar["tem_milhas"] = dados_capturados["tem_milhas"]
    if dados_capturados.get("observacoes"):
        campos_atualizar["observacoes"] = dados_capturados["observacoes"]

    lead_atualizado = atualizar_lead(lead["id"], campos_atualizar)

    # ── 7. Se a Lara agendou uma call: cria agendamento + ficha ──
    if acao == "CRIAR_AGENDAMENTO":
        data_call = dados_capturados.get("data_agendamento", "A confirmar")
        agendamento = criar_agendamento(lead["id"], data_call)
        print(f"[AGENDAMENTO] Call criada para {nome} em {data_call}")

        # Envia a ficha para o Pedro (Workflow 3)
        executar_repasse(lead_atualizado or lead)

    # ── 8. Salva a mensagem enviada pela Lara ──
    salvar_mensagem(
        lead_id=lead["id"],
        direcao="ENVIADA",
        conteudo=mensagem_lara,
        etapa=proxima_etapa,
    )

    # ── 9. Envia a resposta ao lead ──
    enviar_mensagem(whatsapp, mensagem_lara)

    return {"status": "ok", "etapa": proxima_etapa, "acao": acao}


# ─────────────────────────────────────────────
# PONTO DE ENTRADA
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=PORT, reload=False)

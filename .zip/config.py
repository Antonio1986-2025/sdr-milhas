import os

# ─────────────────────────────────────────────
# SUPABASE
# ─────────────────────────────────────────────
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://irnnouhlvtapdkcvlank.supabase.co/rest/v1")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlybm5vdWhsdnRhcGRrY3ZsYW5rIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NTUwODI2MSwiZXhwIjoyMDkxMDg0MjYxfQ.ObKuHLMpyhD8_xfQ1zhvgED33eofX1FPFojPanaH2eY")

# ─────────────────────────────────────────────
# EVOLUTION API (WhatsApp)
# ─────────────────────────────────────────────
EVOLUTION_URL = os.getenv("EVOLUTION_URL", "https://robert-appp-evolution-api.mpysnt.easypanel.host")
EVOLUTION_KEY = os.getenv("EVOLUTION_KEY", "6EF2D801682A-4132-89E9-8FE35107509E")
EVOLUTION_INSTANCE = os.getenv("EVOLUTION_INSTANCE", "sdr-milhas")

# ─────────────────────────────────────────────
# OPENAI
# ─────────────────────────────────────────────
OPENAI_API_KEY = "sua-chave-aqui")
OPENAI_MODEL = "gpt-4o-mini"
OPENAI_MAX_TOKENS = 1000
OPENAI_TIMEOUT = 30

# ─────────────────────────────────────────────
# CONTATOS
# ─────────────────────────────────────────────
WHATSAPP_FECHADOR = os.getenv("WHATSAPP_FECHADOR", "5567996543700")  # Pedro

# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────
PORT = int(os.getenv("PORT", 8000))

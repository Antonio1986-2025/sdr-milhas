"""
agent.py
--------
Aqui fica o "cérebro" da Lara.
Recebe o contexto do lead + histórico de mensagens,
monta o prompt e chama o GPT-4o-mini.
Retorna a resposta já parseada como dicionário Python.
"""

import json
import httpx
from config import OPENAI_KEY, OPENAI_MODEL, OPENAI_MAX_TOKENS, OPENAI_TIMEOUT

# ─────────────────────────────────────────────
# PROMPT DO SISTEMA (personalidade da Lara)
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """Você é Lara, assistente de pré-vendas da Gestao Milhas, especializada em gestão de milhas aéreas.

OBJETIVO ÚNICO: Qualificar o lead e agendar uma call de 30 minutos com Pedro.

TOM: Humano, direto, natural, brasileiro. Use "ta", "pra", "to vendo aqui". Nunca soe robótico.

ETAPAS DA CONVERSA (siga essa ordem):
1. ABERTURA - recepcionar e pedir permissão para fazer perguntas
2. AGUARDANDO_PERMISSAO - aguardar o lead aceitar conversar
3. PERGUNTA_1 - qual o gasto mensal em cartões de crédito?
4. PERGUNTA_2 - quais cartões possui atualmente?
5. PERGUNTA_3 - tem milhas acumuladas? quantas?
6. PERGUNTA_4 - qual destino de viagem desejado?
7. AGENDAMENTO - propor a call com Pedro (ofereça 2 horários)
8. CONFIRMADO - call agendada com sucesso
9. DESCARTADO - lead não tem perfil (gasto abaixo de R$5mil)

REGRAS IMPORTANTES:
1. Faça UMA pergunta por vez — nunca faça duas perguntas na mesma mensagem
2. Nunca revele o preço do serviço — Pedro explica na call
3. Se o gasto mensal for abaixo de R$5.000, descarte com gentileza
4. Se agendar, sempre ofereça 2 opções de horário
5. Responda SEMPRE em JSON puro, sem markdown, sem ```

TEMPERATURA DO LEAD:
- QUENTE: gasto acima de R$15.000/mês e quer agendar
- MORNO: gasto entre R$5.000 e R$15.000, ou está hesitante
- FRIO: gasto abaixo de R$5.000 ou desinteressado
- INDEFINIDO: ainda não coletou dados suficientes

FORMATO OBRIGATÓRIO DE RESPOSTA (JSON puro, sem nada antes ou depois):
{
  "mensagem": "texto para enviar ao lead",
  "proxima_etapa": "ABERTURA|AGUARDANDO_PERMISSAO|PERGUNTA_1|PERGUNTA_2|PERGUNTA_3|PERGUNTA_4|AGENDAMENTO|CONFIRMADO|DESCARTADO",
  "temperatura": "QUENTE|MORNO|FRIO|INDEFINIDO",
  "acao": "NENHUMA|CRIAR_AGENDAMENTO|CANCELAR_AGENDAMENTO",
  "dados_capturados": {
    "gasto_mensal": "valor se capturado, senão null",
    "gasto_faixa": "faixa se identificável (ex: 15-30mil), senão null",
    "cartoes_atuais": "cartões se capturado, senão null",
    "destino_viagem": "destino se capturado, senão null",
    "milhas_atuais": "quantidade se capturado, senão null",
    "tem_milhas": "true/false se capturado, senão null",
    "data_agendamento": "data e hora se agendou, senão null",
    "observacoes": "qualquer info relevante adicional, senão null"
  }
}"""


def formatar_historico(mensagens: list[dict]) -> str:
    """
    Converte a lista de mensagens do banco em texto
    para incluir no prompt do GPT.
    """
    if not mensagens:
        return "Nenhuma mensagem anterior."

    linhas = []
    for msg in mensagens:
        prefixo = "Lead" if msg["direcao"] == "RECEBIDA" else "Lara"
        linhas.append(f"{prefixo}: {msg['conteudo']}")

    return "\n".join(linhas)


def chamar_gpt(lead: dict, mensagem_nova: str, historico: list[dict]) -> dict:
    """
    Chama o GPT-4o-mini e retorna a resposta como dicionário Python.

    lead: dados completos do lead (nome, etapa atual, temperatura, etc.)
    mensagem_nova: última mensagem que o lead enviou
    historico: lista das últimas mensagens da conversa
    """

    # Monta o contexto do lead para o GPT entender a situação atual
    contexto_lead = f"""
DADOS DO LEAD:
- Nome: {lead.get('nome', 'desconhecido')}
- Etapa atual: {lead.get('etapa', 'ABERTURA')}
- Temperatura: {lead.get('temperatura', 'INDEFINIDO')}
- Gasto mensal: {lead.get('gasto_mensal') or 'ainda não informado'}
- Cartões: {lead.get('cartoes_atuais') or 'ainda não informado'}
- Destino viagem: {lead.get('destino_viagem') or 'ainda não informado'}
- Milhas atuais: {lead.get('milhas_atuais') or 'ainda não informado'}

HISTÓRICO DA CONVERSA:
{formatar_historico(historico)}

NOVA MENSAGEM DO LEAD:
{mensagem_nova}
"""

    # Monta a requisição para a OpenAI
    payload = {
        "model": OPENAI_MODEL,
        "max_tokens": OPENAI_MAX_TOKENS,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": contexto_lead},
        ],
    }

    headers = {
        "Authorization": f"Bearer {OPENAI_KEY}",
        "Content-Type": "application/json",
    }

    resp = httpx.post(
        "https://api.openai.com/v1/chat/completions",
        headers=headers,
        json=payload,
        timeout=OPENAI_TIMEOUT,
    )
    resp.raise_for_status()

    # Extrai o texto da resposta
    texto_resposta = resp.json()["choices"][0]["message"]["content"].strip()

    # Remove possíveis blocos markdown caso o GPT desobedeça (ex: ```json ... ```)
    if texto_resposta.startswith("```"):
        linhas = texto_resposta.split("\n")
        texto_resposta = "\n".join(linhas[1:-1])

    # Converte o JSON em dicionário Python
    try:
        return json.loads(texto_resposta)
    except json.JSONDecodeError:
        # Se o GPT retornou algo inválido, retorna uma resposta padrão segura
        return {
            "mensagem": "Oi! Pode repetir? Não entendi muito bem o que você disse 😊",
            "proxima_etapa": lead.get("etapa", "ABERTURA"),
            "temperatura": lead.get("temperatura", "INDEFINIDO"),
            "acao": "NENHUMA",
            "dados_capturados": {},
        }
